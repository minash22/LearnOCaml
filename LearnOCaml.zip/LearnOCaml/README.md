# LearnOCaml
Learn OCaml from Scratch is a student-friendly guide to functional programming with OCaml.
It includes clear examples, chapter-by-chapter exercises, and a full mini project.
Each chapter has its own .ml file with runnable code and practice.
Topics include functions, recursion, pattern matching, records, variants, modules, safe code, and more

